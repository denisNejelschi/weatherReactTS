import React, { useEffect, useState } from "react";
import style from "./weatherApp.module.css";
import { useFormik } from "formik";
import * as Yup from "yup";

const initialValues = {
  location: "",
};
interface WeatherData{
  name: string;
  main: {
    temp: number;
    feels_like: number;
    humidity: number;
  };
  weather: [
    {
      description: string;
      icon: string;
      id:number;
      main:string;
    }
  ];
  wind: {
    speed: number;
  };
  sys: {
    country: string;
  };
  dt: number;
}

export default function WeatherApp() {
  const [weather, setWeather] = useState<WeatherData>({} as WeatherData);
  const [location, setLocation] = useState("");

  const formik = useFormik({
    initialValues: initialValues,
    validationSchema: Yup.object({
      location: Yup.string().required("Required"),
    }),
    onSubmit: (values) => {
      // setLocation(values.location);
      async function getWeather(value: string) {
        const response = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?q=${value}&units=metric&appid=42283fd1cd2294032a234a8e7a5213ca`
        );
        const data = await response.json();
        setWeather(data);
        console.log(data);
      }

      getWeather(values.location);
      
    },
  });

  useEffect(() => { 

  }, []);
;
  return (
    <div className={style.weatherAppContainer}>
      <h1>Weather App</h1>
      <form onSubmit={formik.handleSubmit}>
        <input
          placeholder="Enter Location"
          id="location"
          name="location"
          type="text"
          onChange={formik.handleChange}
          value={formik.values.location}
        />
        <button type="submit">Submit</button>
      </form>
    <p>{weather.main?.temp}</p>
      {weather.main &&(
        <div className={style.weatherContainer}>
        <h2>Weather in: {weather.name}</h2>
        <p>Country: {weather.sys.country}</p>
         <p>Temperature: {weather.main.temp} C</p>
         <p>Feels Like: {weather.main.feels_like} C</p>
         <p>Humidity: {weather.main.humidity} %</p>
         <p>Description: {weather.weather[0].description}</p>
         <p>Wind Speed: {weather.wind.speed} M/S</p>
         <img  src={`https://openweathermap.org/img/w/${weather.weather[0].icon}.png`} alt="" />
         
       </div>
      )}
      
    </div>
  );
}
